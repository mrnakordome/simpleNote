package com.example.simplenote.ui.register

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simplenote.data.model.RegisterRequest
import com.example.simplenote.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class RegisterUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val success: Boolean = false
)

class RegisterViewModel(private val repo: AuthRepository) : ViewModel() {
    private val _ui = MutableStateFlow(RegisterUiState())
    val ui: StateFlow<RegisterUiState> = _ui

    fun register(
        username: String,
        password: String,
        email: String,
        firstName: String,
        lastName: String
    ) {
        _ui.value = RegisterUiState(loading = true)
        viewModelScope.launch {
            val res = repo.register(
                RegisterRequest(username, password, email, firstName, lastName)
            )
            _ui.value = if (res.isSuccess) {
                RegisterUiState(success = true)
            } else {
                RegisterUiState(error = res.exceptionOrNull()?.message)
            }
        }
    }
}
