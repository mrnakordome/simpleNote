package com.example.simplenote.data.model

data class RefreshRequest(
    val refresh: String
)
