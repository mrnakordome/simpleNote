package com.example.simplenote.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.simplenote.ui.login.LoginScreen
import com.example.simplenote.ui.onboarding.OnboardingScreen

object Routes {
    const val Onboarding = "onboarding"
    const val Login = "login"
    const val Register = "register"
}

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Routes.Onboarding) {
        composable(Routes.Onboarding) {
            OnboardingScreen(onGetStarted = { navController.navigate(Routes.Login) })
        }
        composable(Routes.Login) {
            com.example.simplenote.ui.login.LoginScreen(
                onLogin = { _, _ -> /* TODO */ },
                onRegister = { navController.navigate(Routes.Register) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.Register) {
            com.example.simplenote.ui.register.RegisterScreen(
                onRegister = { _, _, _, _, _ -> /* TODO: API */ },
                onBackToLogin = { navController.popBackStack() }
            )
        }
    }
}
