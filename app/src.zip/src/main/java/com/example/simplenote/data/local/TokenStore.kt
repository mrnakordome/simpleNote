package com.example.simplenote.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("auth_store")

class TokenStore(private val context: Context) {
    companion object {
        private val KEY_ACCESS = stringPreferencesKey("access_token")
        private val KEY_REFRESH = stringPreferencesKey("refresh_token")
    }

    val accessToken: Flow<String?> =
        context.dataStore.data.map { it[KEY_ACCESS] }

    val refreshToken: Flow<String?> =
        context.dataStore.data.map { it[KEY_REFRESH] }

    suspend fun saveTokens(access: String, refresh: String?) {
        context.dataStore.edit {
            it[KEY_ACCESS] = access
            if (refresh != null) it[KEY_REFRESH] = refresh
        }
    }

    suspend fun clear() {
        context.dataStore.edit { it.clear() }
    }
}
