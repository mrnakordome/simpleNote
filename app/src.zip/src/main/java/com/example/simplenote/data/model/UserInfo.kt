package com.example.simplenote.data.model

data class UserInfo(
    val id: Int,
    val username: String,
    val email: String,
    val first_name: String?,
    val last_name: String?
)
