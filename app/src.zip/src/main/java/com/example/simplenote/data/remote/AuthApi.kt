package com.example.simplenote.data.remote

import com.example.simplenote.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface AuthApi {
    @POST("auth/register/")
    suspend fun register(@Body body: RegisterRequest): Response<RegisterResponse>

    @POST("auth/token/")
    suspend fun login(@Body body: TokenRequest): Response<TokenResponse>

    @POST("auth/token/refresh/")
    suspend fun refresh(@Body body: RefreshRequest): Response<AccessOnlyResponse>

    @GET("auth/userinfo/")
    suspend fun userInfo(@Header("Authorization") bearer: String): Response<UserInfo>
}
