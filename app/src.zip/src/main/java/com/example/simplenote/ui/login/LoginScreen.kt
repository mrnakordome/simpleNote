package com.example.simplenote.ui.login

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simplenote.ui.theme.AppPurple
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider

@Composable
fun LoginScreen(
    onLogin: (email: String, pass: String) -> Unit,
    onRegister: () -> Unit,
    onBack: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Spacer(Modifier.height(8.dp))

        Text(
            text = "Let’s Login",
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF1E1E1E),
            modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
        )
        Text(
            text = "And notes your idea",
            fontSize = 16.sp,
            color = Color(0xFF9A9AA0),
            modifier = Modifier.padding(bottom = 28.dp)
        )

        Text("Email Address", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1E1E1E))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            placeholder = { Text("Example: johndoe@gmail.com", color = Color(0xFFB9B9BF)) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFFE3E3EA),
                unfocusedBorderColor = Color(0xFFE3E3EA),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                cursorColor = AppPurple
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(20.dp))

        Text("Password", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1E1E1E))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pass,
            onValueChange = { pass = it },
            placeholder = { Text("*********", color = Color(0xFFB9B9BF)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFFE3E3EA),
                unfocusedBorderColor = Color(0xFFE3E3EA),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                cursorColor = AppPurple
            ),
            modifier = Modifier.fillMaxWidth()
        )


        Spacer(Modifier.height(28.dp))

        Button(
            onClick = { onLogin(email, pass) },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(100),
            colors = ButtonDefaults.buttonColors(
                containerColor = AppPurple,
                contentColor = Color.White
            ),
        ) {
            Text("Login", fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
        }

        Spacer(Modifier.height(18.dp))

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            HorizontalDivider(
                modifier = Modifier.weight(1f),
                thickness = DividerDefaults.Thickness,
                color = Color(0xFFE9E9EE)
            )
            Text("  Or  ", color = Color(0xFF9A9AA0))
            HorizontalDivider(
                modifier = Modifier.weight(1f),
                thickness = DividerDefaults.Thickness,
                color = Color(0xFFE9E9EE)
            )
        }

        Spacer(Modifier.height(18.dp))

        val registerText = buildAnnotatedString {
            append("Don’t have any account? ")
            withStyle(SpanStyle(color = AppPurple, fontWeight = FontWeight.SemiBold)) {
                append("Register here")
            }
        }
        TextButton(
            onClick = onRegister,
            shape = CircleShape,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text(registerText, color = AppPurple, textAlign = TextAlign.Center)
        }
    }
}
