package com.example.simplenote.data.model

data class TokenRequest(
    val username: String,
    val password: String
)
