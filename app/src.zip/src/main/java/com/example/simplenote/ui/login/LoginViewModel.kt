package com.example.simplenote.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simplenote.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class LoginUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val success: Boolean = false
)

class LoginViewModel(private val repo: AuthRepository) : ViewModel() {
    private val _ui = MutableStateFlow(LoginUiState())
    val ui: StateFlow<LoginUiState> = _ui

    fun login(username: String, password: String) {
        _ui.value = LoginUiState(loading = true)
        viewModelScope.launch {
            val res = repo.login(username, password)
            _ui.value = if (res.isSuccess) {
                LoginUiState(success = true)
            } else {
                LoginUiState(error = res.exceptionOrNull()?.message)
            }
        }
    }
}
