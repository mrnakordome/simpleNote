package com.example.simplenote.data.model

data class AccessOnlyResponse(
    val access: String
)
