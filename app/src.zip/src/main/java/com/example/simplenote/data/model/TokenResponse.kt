package com.example.simplenote.data.model

data class TokenResponse(
    val access: String,
    val refresh: String
)
