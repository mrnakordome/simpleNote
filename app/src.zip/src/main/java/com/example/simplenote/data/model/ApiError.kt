package com.example.simplenote.data.model

data class ApiError(
    val type: String? = null,
    val errors: List<Map<String, List<String>>>? = null,
    val detail: String? = null
)
