package com.example.simplenote.data.repository

import com.example.simplenote.data.local.TokenStore
import com.example.simplenote.data.model.*
import com.example.simplenote.data.remote.NetworkModule
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import retrofit2.Response

class AuthRepository(
    private val tokenStore: TokenStore,
    private val moshi: Moshi
) {
    private val api = NetworkModule.authApi
    private val errorAdapter = moshi.adapter(ApiError::class.java)

    private fun <T> parseError(resp: Response<T>): ApiError {
        val bodyStr = resp.errorBody()?.string()
        return bodyStr?.let { errorAdapter.fromJson(it) } ?: ApiError(type = "unknown_error")
    }

    suspend fun register(req: RegisterRequest): Result<RegisterResponse> =
        withContext(Dispatchers.IO) {
            val r = api.register(req)
            if (r.isSuccessful && r.body() != null) {
                Result.success(r.body()!!)
            } else {
                Result.failure(Exception(parseError(r).toString()))
            }
        }

    suspend fun login(username: String, password: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            val r = api.login(TokenRequest(username, password))
            if (r.isSuccessful && r.body() != null) {
                val body = r.body()!!
                tokenStore.saveTokens(body.access, body.refresh)
                Result.success(Unit)
            } else {
                Result.failure(Exception(parseError(r).toString()))
            }
        }

    suspend fun userInfo(): Result<UserInfo> = withContext(Dispatchers.IO) {
        val token = tokenStore.accessToken.first()
        if (token.isNullOrBlank()) return@withContext Result.failure(Exception("no_token"))
        val r = api.userInfo("Bearer $token")
        if (r.isSuccessful && r.body() != null) {
            Result.success(r.body()!!)
        } else {
            Result.failure(Exception(parseError(r).toString()))
        }
    }

    suspend fun refresh(): Result<Unit> = withContext(Dispatchers.IO) {
        val refresh = tokenStore.refreshToken.first() ?: return@withContext Result.failure(Exception("no_refresh"))
        val r = api.refresh(RefreshRequest(refresh))
        if (r.isSuccessful && r.body() != null) {
            tokenStore.saveTokens(r.body()!!.access, null)
            Result.success(Unit)
        } else {
            Result.failure(Exception(parseError(r).toString()))
        }
    }

    suspend fun logout() = tokenStore.clear()
}
